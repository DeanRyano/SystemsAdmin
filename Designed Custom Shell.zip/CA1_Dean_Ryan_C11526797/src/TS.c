/*
  Systems Integration Assignment 1
       C11526797 - Dean Ryan
             21/10/15
       		TSH
**/


#include <string.h> //String Operations
#include <unistd.h> //Constants and types
#include <stdio.h> //I/O functions
#include <time.h> //Time types
#include <pwd.h> //Password Structure
#include <grp.h> //Group Structure
#include <stdlib.h> //Standard functions
#include <fcntl.h> //File control Options
#include <stdint.h> //Integer types
#include <sys/types.h> //Data types
#include <sys/wait.h> //Declarations for waiting
#include <sys/socket.h> //Internet Protocol Family
#include <netdb.h> //Definitions for network database operations (IP)
#include <arpa/inet.h> //Internet operations
#include "my_header.h" //Header File

#define T_RL_BUFSIZE 1024 //Macro and its token (1024 - gcc compiler)
#define T_TOK_BUFSIZE 64 //Macro + Token
#define T_TOK_DELIM " \t\r\n\a" //Tokenizing t\r\n\a

//Function Declarations for shell commands:
int t_cd(char **args);
int t_hlp(char **args);
int t_dt(char **args);
int t_ud(char **args);
int t_exit(char **args);
int t_pw(char **args);
int t_ifc(char **args);
int t_ifu(char **args);
int t_ifd(char **args);
int t_tch(char **args);
int t_rm(char **args);
int t_ls(char **args);
int t_cl(char **args);
int t_gadd(char **args);	
int t_ping(char **args);
int t_ntst(char **args);
int t_hn(char **args);
int t_trph(char **args);
int t_rte(char **args);
int t_rteadd(char **args);
int t_rtedel(char **args);
int t_crp(char **args);
int t_man(char **args);


//Array of names (pointers)
char *IE_str[] = {
  "cd",
  "hlp",
  "dt",
  "ud",
  "exit",
  "pw",
  "ifc",
  "ifu",
  "ifd",
  "tch",
  "rm",
  "ls",
  "cl",
  "gadd",
  "ping",
  "ntst",
  "hn",
  "trph",
  "rte",
  "rteadd",
  "rtedel",
  "crp",
  "man"
};

//Array of functions
int (*IE_func[]) (char **) = {
  &t_cd,
  &t_hlp,
  &t_dt,
  &t_ud,
  &t_exit,
  &t_pw,
  &t_ifc,
  &t_ifu,
  &t_ifd,
  &t_tch,
  &t_rm,
  &t_ls,
  &t_cl,
  &t_gadd,
  &t_ping,
  &t_ntst,
  &t_hn,
  &t_trph,
  &t_rte,
  &t_rteadd,
  &t_rtedel,
  &t_crp,
  &t_man
};

//ie. cds position is assigned to &t_cds and so on
int t_num_IE() {
  return sizeof(IE_str) / sizeof(char *);
}


/////////////////////////////////////////
/**
   INTERNAL COMMANDS
 */
/////////////////////////////////////////



/**
   Internal command: change directory.
   Args[0] is "cd".  args[1] is the directory(user input).
   Always returns 1, to continue executing.
   Chdir() to argument 1 - if not then return error
 */
int t_cd(char **args)
{
  if (args[1] == NULL) {
    fprintf(stderr, "tsh error: argument expected after \"cd\"\n");
  } else {
    if (chdir(args[1]) != 0) {
      perror("tsh"); 
    }
  }
  return 1;
}

/**
   Internal command: change directory.
   Function help returns description of shell.
   for loop displays the available I/E functions.
 */
int t_hlp(char **args)
{
  int i;

  printf("\nThis is a custom shell designed in C.The purpose\nof the shell is to present a limited set of functionality\nto a Linux system user such that they can examine and set\na limited selection of network related settings on Linux.\n");
  printf("-----------------------------------------------------------\n");
  printf("The following are internal and external commands available:\n");
  printf("-----------------------------------------------------------\n");

  for (i = 0; i < t_num_IE(); i++) {
    printf("  %s \n", IE_str[i]);
  }


  printf("-----------------------------------------------------------\n\n");
  return 1;
}



/**
   Internal command: Date/time.
   Displays current date and time on the system.
   time_t - stores system timed values 
   time() - returns current calendar
   strftime() - convrerts the struct to the string specified y/m/d/h/m/s
 */
int t_dt(char **args)
{

  time_t rawtime; 
  struct tm *info; //Allows us to combine datatypes of different kinds ie. tm *info
  char buffer[80];

  time( &rawtime );

  info = localtime( &rawtime );

  strftime(buffer, 80, "%Y%m%d%H%M%S \n", info);
  printf("%s\n", buffer);

  return 1; 
}


/**
   Internal command: User Details.
   Displays UserId, GroupId, UserName, GroupName, Inode of home directory.
*/
int t_ud(char **args)
{

  gid_t gid;
  uid_t uid;

  struct passwd *passwd;
  struct group *grp;
  struct stat statbuf;

  passwd = getpwuid (getuid());
  uid=getuid();
  grp=getgrgid(gid);

  printf("%d, %d, %s , %s, %ld \n", uid, grp->gr_gid, passwd->pw_name, grp->gr_name, statbuf.st_ino );

 return 1;
}
/**
   Internal command: Exit.
   Function exits program from returning 0.
   External system call used to 'Notify' the user.
 */

int t_exit(char **args)
{
  char *arg = "Logged Off";
  char * t_args[3] = {"notify-send", arg, NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }
  return 0;
}

/**
   Internal command: Clear.
   Used to clear the screen of the shell.
   Internal system call 'cl' used.
   Works on ANSI terminals. (Escape sequence)
 */
int t_cl(char **args){

  const char* CLEAR_SCREE_ANSI = "\e[1;1H\e[2J";
  write(STDOUT_FILENO,CLEAR_SCREE_ANSI,12);

  return 1;
}

/**
   Internal command: Get Address.
   Used to return the Ip of a host.
   Internal system call 'gadd' used.
   Moddified code from - http://www.binarytides.com/hostname-to-ip-address-c-sockets-linux/
 */
int t_gadd(char **args){

   char *hostn = args[1];
   char ip[100];
   int sockfd;
   struct addrinfo hints, *servinfo, *p;
   struct sockaddr_in *h;
   int rv;

   memset(&hints, 0, sizeof hints);
   hints.ai_family = AF_UNSPEC; // use AF_INET6 to force IPv6
   hints.ai_socktype = SOCK_STREAM;

   if ( (rv = getaddrinfo( hostn , "http" , &hints , &servinfo)) != 0) 
   {
       fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
       return 1;
   }

   // loop through all the results and connect to the first we can
   for(p = servinfo; p != NULL; p = p->ai_next)
   {
       h = (struct sockaddr_in *) p->ai_addr;
       strcpy(ip , inet_ntoa( h->sin_addr ) );
   }
   freeaddrinfo(servinfo);


  printf("%s resolved to %s\n" , hostn, ip);
  printf("\n");

  return 1;
}

/////////////////////////////////////////
/**
   EXTERNAL COMMANDS 
 */
/////////////////////////////////////////



/**
   External command: Present Working Directory.
   Used to print the present working directory to the user.
   External system call 'pwd' used.
 */

int t_pw(char **args){

  char * t_args[2] = {"pwd", NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;

}

/**
   External command: IFCONFIG.
   Used to return the ip addressing and usage statistics of interface en0/lo.
   External system call 'ifconfig' used.
 */

int t_ifc(char **args){

  char *arg = args[1];
  char * t_args[5];
  if (arg == NULL){
    char * t_args[5] = {"strace", "-c", "/sbin/ifconfig", "en0", NULL};
  }else{ 
    char * t_args[5] = {"strace", "-c", "/sbin/ifconfig", arg, NULL};
  }
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}

/**
   External command: ifup.
   Used to bring an interface up by following a script.
   Args[0] is "ifup".  args[1] is the interface(user input).
   External system call 'ifu' used.
 */

int t_ifu(char **args){

  char *arg = args[1];
  char * t_args[3] = {"/sbin/ifup", arg, NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}



/**
   External command: ifdown.
   Used to bring an interface down by following a script.
   Args[0] is "ifd".  args[1] is the interface(user input).
   External system call 'ifd' used.
 */

int t_ifd(char **args){

  char *arg = args[1];
  char * t_args[3] = {"/sbin/ifdown", arg, NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}


/**
   External command: touch.
   Used to create a new file type.
   Args[0] is "tch".  args[1] is the Filename(user input).
   External system call 'touch' used.
   Strcat allows us to specifty a destination/src (commandline/touch)
 */

int t_tch(char **args){

  char *arg = args[1];
  char * t_args[3] = {"touch", arg, NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }


return 1;
}


/**
   External command: Remove.
   Used to remove a file type.
   Args[0] is "rm".  args[1] is the Filename(user input).
   External system call 'rm' used.
   Strcat allows us to specifty a destination/src (commandline/touch)
 */

int t_rm(char **args){

  char *arg = args[1];
  char * t_args[3] = {"rm", arg, NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }


return 1;
}

/**
   External command: List Files.
   Used to list files in the current working directory
   External system call 'ls' used.
   Strcat allows us to specifty a destination/src (commandline/touch)
 */

int t_ls(char **args){

  char * t_args[2] = {"ls", NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execve failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}


/**
   External command: Ping.
   Used to ping to establish a connection from one host to another.
   Args[0] is "ping".  args[1] is the address(user input).
   External system call 'touch' used.
   Strcat allows us to specifty a destination/src (commandline/touch)
 */
int t_ping(char **args){

  char *arg = args[1];
  char * t_args[4] = {"ping", "-w5", arg, NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}

/**
   External command: Netstat.
   Used to display contents of /proc/net files..Status of ports etc..
   External system call 'ntst' used.
 */
int t_ntst(char **args){

  char *arg = args[1];
  char * t_args[2] = {"netstat", NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}

/**
   External command: Hostname.
   Used to display the hostname of the system.
   External system call 'hn' used.
 */

int t_hn(char **args){

  char *arg = args[1];
  char * t_args[2] = {"hostname", NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}


/**
   External command: tracepath.
   Used to list hosts through which packets travel.
   External system call 'trph' used.
 */

int t_trph(char **args){

  char *arg = args[1];
  char * t_args[3] = {"tracepath", arg, NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}


/**
   External command: Route.
   Used to display the routing table.
   External system call 'rte' used.
 */

int t_rte(char **args){

  char * t_args[2] = { "/sbin/route", NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}


/**
   External command: Route add.
   Used to modify the routing table.
   External system call 'rteadd' used.
 */

int t_rteadd(char **args){

  char *arg = args[1];
  char * t_args[7] = {"ip", "route", "add", arg, "dev", "wlan0", NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}



/**
   External command: Route Del.
   Used to modify the routing table.
   External system call 'rtedel' used.
 */

int t_rtedel(char **args){

  char *arg = args[1];
  char * t_args[7] = {"ip", "route", "del", arg, "dev", "wlan0", NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}


/**
   External command: ps -aux.
   Used to modify the routing table.
   External system call 'rtedel' used.
 */

int t_crp(char **args){

  char * t_args[3] = {"ps", "-aux", NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}


/**
   External command: man.
   Used to modify the routing table.
   External system call 'rtedel' used.
 */

int t_man(char **args){

  char * t_args[5] = {"cd", "../doc/", "cat", "man.txt", NULL};
  pid_t c_pid, pid;
  int status;

  c_pid = fork();

  if (c_pid == 0){
    //CHILD
    execvp( t_args[0], t_args);
    perror("execvpp failed");
  }else if (c_pid > 0){
    //PARENT
    if( (pid = wait(&status)) < 0){
      perror("wait");
      return 0;
    }
  }else{
    perror("fork failed");
    return 0;
  }

return 1;
}


/////////////////////////////////////////
/**
   Reading a line from Stdin. (Bufsize)
 */
/////////////////////////////////////////
char *t_read_line(void)
{

  //Initializing memory allocation (buffer)
  int bufsize = T_RL_BUFSIZE;
  int position = 0;
  char *buffer = malloc(sizeof(char) * bufsize); // 
  int c;

  if (!buffer) {
    fprintf(stderr, "tsh: allocation error\n");
    exit(EXIT_FAILURE);
  }

  while (1) {
    // Read a character
    c = getchar();

    // If End of File is hit, replace it with null character and return.
    if (c == EOF || c == '\n') {
      buffer[position] = '\0';
      return buffer;
    } else {
      buffer[position] = c;
    }
    position++;

    // If buffer exceeded, reallocate.
    if (position >= bufsize) {
      bufsize += T_RL_BUFSIZE;
      buffer = realloc(buffer, bufsize);
      if (!buffer) {
        fprintf(stderr, "tsh: allocation error\n");
        exit(EXIT_FAILURE);
      }
    }
  }

}

/////////////////////////////////////////
/**
   Splits line into tokens(T_TOK_BUFSIZE)
*/
/////////////////////////////////////////
char **t_split_line(char *line)
{

  //Initializing memory allocation (buffer)
  int bufsize = T_TOK_BUFSIZE, position = 0;
  char **tokens = malloc(bufsize * sizeof(char*));
  char *token;

  if (!tokens) {
    fprintf(stderr, "tsh: allocation error\n");
    exit(EXIT_FAILURE);
  }

  //Strtok breaks line into T_TOK_DELIM(\t\r\n\a) - ie. Accepted  
  token = strtok(line, T_TOK_DELIM);
  while (token != NULL) {
    tokens[position] = token; //Start at 0 and increment
    position++;

    // If buffer exceeded, reallocate.
    if (position >= bufsize) {
      bufsize += T_TOK_BUFSIZE;
      tokens = realloc(tokens, bufsize * sizeof(char*));
      if (!tokens) {
        fprintf(stderr, "tsh: allocation error\n");
        exit(EXIT_FAILURE);
      }
    }
    token = strtok(NULL, T_TOK_DELIM);
  }
  tokens[position] = NULL;
  return tokens;
}

/////////////////////////////////////////

/**
   Executes the Internal/External functions.
 */
/////////////////////////////////////////

int t_execute(char **args)
{

  int i;

  if (args[0] == NULL) {
    // An empty command was entered.
    return 1;
  }

  //Loop that compares user args to IE_str
  for (i = 0; i < t_num_IE(); i++) {
    if (strcmp(args[0], IE_str[i]) == 0) {
      //Returns corresponding function to user arg 
      return (*IE_func[i])(args);
    }
  }

  return 1;
}

/////////////////////////////////////////

/**
   Loop which gets input and executes it.
 */
/////////////////////////////////////////

//We use void because of no return value
void t_loop(void)
{
  //Declarations
  char *line;
  char **args;
  int status;

  do {
    int y = header();
    printf("tsh > "); //Print prompt
    line = t_read_line(); //read_line() 
    args = t_split_line(line); //split_line() 
    status = t_execute(args); //Execute arguments
    free(line); //Functions which deallocates(releases) the memory of the pointers
    free(args); 
  } while (status); //After an arguments is executed - Exit
}


//Calling the loop function 
//argc (count)- Number of args passed through main
//argv (vector)- Array of strings 
int main(int argc, char **argv)
{
  // Run command loop.
  t_loop();

}


