#==========#
|tiny shell|
#==========#

- Dean Ryan
- C11526797
- Systems Integration - CA1
----------------------------

Description
-----------

Tsh is a tiny shell for Unix systems.
Tsh is written in C.
It's use is to give users (Network admins) an easy but limited access to a system and its commands.
One can set this shell as a users login shell.


Installation
------------

Requirement: C compiler (gcc)

Unpack the zip folder, and just copy the executable `TS` into
`/usr/local/bin` 

> sudo cp TS /bin/TS (copies the exe into /bin/TS using sudo)

==
OR
==

cd into the diretory where the TS.c file is saved and run the following commands

> gcc TS.c -o ../bin/TS (compiles the c file, changes directory into the bin folder and creates the exe file  
> ./TS  (Runs the exe file)


Files
-----

  - `TS.c' contains the functions and main required to start the tinyshell.

  - `my_header.h` contains a print statement that provides the user with the help command if they need/forget it.










Man page

references on what was used..nano, gcc, get address command link

